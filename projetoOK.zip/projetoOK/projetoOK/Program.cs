﻿     Console.WriteLine("digite um valor");
    int valor =Convert.ToInt32(Console.ReadLine());
    if (valor > 10) Console.WriteLine("ok");

    else if (valor < 10)
    {
    Console.WriteLine("proximos numeros");
    int contador = 0;
    while (contador < 8) 
    {
        Console.WriteLine( valor + contador + 1);
        contador++;
    }

    }
