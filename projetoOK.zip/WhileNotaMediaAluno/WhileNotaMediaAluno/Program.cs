﻿int TotalAlunos = 5;
int alunoatual = 1;

while(alunoatual < TotalAlunos)
{
    Console.WriteLine("nome do primeiro aluno")
    Console.WriteLine($"Digite as notas do {alunoatual} ° aluno:");

    double soma = 0;
    int contador = 0;

    while (contador<3 )
    { Console.WriteLine($"Digite a {contador + 1 } ª nota:");
        double nota = Convert.ToDouble(Console.ReadLine()) ;
        soma += nota;
        contador++;
    }

    double media = soma / 3;
    Console.WriteLine($"A média do {alunoatual} é {media}\n");
    alunoatual++;

    if ( alunoatual >= 7
}