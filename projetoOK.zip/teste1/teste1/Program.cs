﻿int i, notas;
string nome;
i = 1;
while (i<5)
{
    Console.WriteLine("digite o nome do aluno");
    nome = Console.ReadLine();
    Console.WriteLine("digite a nota");
    notas = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("O Aluno " + nome +
        "teve a nota " + notas);


}