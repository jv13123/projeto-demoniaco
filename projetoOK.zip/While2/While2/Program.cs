﻿int i, valor;
string nome;
i = 1;
while (i<2)
{
    Console.WriteLine("digite o seu nome");
    nome = Console.ReadLine();
    Console.WriteLine("Digite o valor da multiplicação");
    valor = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("o valor multiplicado em sequencia de 7 é ");
    Console.WriteLine((valor * 3));
    Console.WriteLine((valor * 6));
    Console.WriteLine((valor * 9));
    Console.WriteLine((valor * 12));
    Console.WriteLine((valor * 15));
    Console.WriteLine((valor * 18));
    Console.WriteLine((valor * 21));
}
